<x-mail::message>
# Welcome Message

NCCFIMO welcomes you to the body of chirst, we hope you are doing fine.
God bless you.

<x-mail::button :url="'https://nccfimo.org.ng/'">
Back To Site
</x-mail::button>

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
